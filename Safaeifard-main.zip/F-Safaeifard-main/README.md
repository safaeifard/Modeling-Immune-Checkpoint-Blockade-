Branch CBM-PyDream: Constraint-Based Model of a Toy Metabolic Network for Stochastic Constraints Estimation (based on DREAM algorithm - incomplete)
